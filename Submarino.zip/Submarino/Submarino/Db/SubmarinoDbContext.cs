﻿using Microsoft.EntityFrameworkCore;
using Submarino.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Submarino.Db
{
    public class SubmarinoDbContext : DbContext
    {
        public SubmarinoDbContext(DbContextOptions<SubmarinoDbContext> db)
            :base(db)
        {

        }

        public DbSet<Produto> Produtos { get; set; }
    }
}
