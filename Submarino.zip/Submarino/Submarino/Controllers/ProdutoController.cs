﻿
using Microsoft.AspNetCore.Mvc;
using Submarino.Models;
using Submarino.Services;
using System.Linq;

namespace Submarino.Controllers
{
    public class ProdutoController : Controller
    {
        private readonly ProdutoService produtoService;

        public ProdutoController(ProdutoService produtoService)
        {
            this.produtoService = produtoService;
        }

        public IActionResult Index()
        {
            var produtos = produtoService.GetProdutos();

            produtos.Where(a => a.Preco == 1);

            return View(produtos);
        }

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(Produto produto)
        {
            if (!ModelState.IsValid)
            {
                return View(produto);
            }

            var resultado = produtoService.Salvar(produto);

            if (resultado == true)
                return View("Index", produtoService.GetProdutos());
            else
                return View("Error");
        }
    }
}