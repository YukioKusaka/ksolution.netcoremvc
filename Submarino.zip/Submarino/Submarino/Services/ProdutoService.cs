﻿using Submarino.Db;
using Submarino.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Submarino.Services
{
    public class ProdutoService
    {
        private readonly SubmarinoDbContext db;

        public ProdutoService(SubmarinoDbContext db)
        {
            this.db = db;
        }

        public List<Produto> GetProdutos()
        {
            List<Produto> produtos = db.Produtos.ToList();

            return produtos;
        }

        public List<Produto> GetProdutosMenoPreco(int preco)
        {
            List<Produto> produtos = db.Produtos
                .Where(a => a.Preco <= preco).ToList();

            return produtos;
        }

        public bool Salvar(Produto produto)
        {
            bool salvou = false;

            db.Produtos.Add(produto);
            var resultado = db.SaveChanges();

            if (resultado > 0)
                salvou = true;

            return salvou;
        }
    }
}
