﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Submarino.Migrations
{
    public partial class CreateColumnMyColumn : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "MyColumn",
                table: "Produtos",
                nullable: false,
                defaultValue: 0);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "MyColumn",
                table: "Produtos");
        }
    }
}
